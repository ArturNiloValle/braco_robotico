QueueArray
==========

QueueArray Library For Arduino

this contains some changes I have made to the Arduino Queue Array Library:

* predefined size
* more relaxed returns for less checks
